#include <stdio.h>
#include <dlfcn.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
	void *handle;

	handle =  dlopen("tiny.so",RTLD_NOW);
	if (handle) 
		printf("loaded shared library\n");
	else {
		printf("could not load shared library\n");
		return (-1);
	}
	sleep(1);
	dlclose(handle);
  return 0;
}
