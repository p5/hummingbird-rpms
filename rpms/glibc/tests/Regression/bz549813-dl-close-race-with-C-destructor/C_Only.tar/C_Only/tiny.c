#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
pthread_t t;


void *F(void *arg) {

	int old;
	if (pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, &old) == 0) {
		printf("> cancelability enabled.\n");
	}
	else {
		printf("> could not set cancelability\n");
		return (0);
	}

	sleep(2);
} /*end F */

int _init_rick (void) {

printf("in init\n");
    if (pthread_create(&t, NULL, (void *(*)(void *)) F, NULL) == 0) 
	printf("started thread\n");
else
	printf("could not start thread\n");

} /* end _init_rick */

int _fini_rick (void) {

	printf("in fini\n");

	printf("canceling thread\n");
	if (pthread_cancel(t) == 0)
		printf("canceled thread\n");
	else
		printf("could not cancel thread \n");
	
	printf("joining thread\n");
	if (pthread_join(t, NULL) == 0)
		printf("joined with thread\n");
	else
		printf("could not join with thread\n");


} /* end _fini_rick */
