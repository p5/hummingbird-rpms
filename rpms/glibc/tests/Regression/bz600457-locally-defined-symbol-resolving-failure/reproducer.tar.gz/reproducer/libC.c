#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>

void _libC_fini()
{
	printf("7)libC:finish - atexit()\n");
}
void libC_fini()
{
	_libC_fini();
}

void libC_func()
{
        void *libB;

	printf("4)libC:dlopen  libB.so\n");
        libB = dlopen("libB.so", RTLD_LAZY);
	if (!libB) {
		printf("dlopen error:libB.so:%s\n",dlerror());
		exit(-1);
	}
	
	printf("5)libC:atexit(libC_fini)\n");
	atexit(libC_fini);
}
