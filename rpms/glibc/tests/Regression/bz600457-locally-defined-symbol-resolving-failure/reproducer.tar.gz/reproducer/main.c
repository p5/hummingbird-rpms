#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int main()
{
        void *libA, *libX;
	void (*libAfn)();


	printf("1)main:dlopen  libA.so\n");
        libA = dlopen("libA.so", RTLD_LAZY);
	if (!libA) {
		printf("dlopen error:libA.so:%s\n",dlerror());
		exit(-1);
	}

	printf("2)main:dlopen  libX.so\n");
	libX = dlopen("libX.so", RTLD_LAZY);
	if (!libX) {
		printf("dlopen error:libX.so:%s\n",dlerror());
		exit(-1);
	}
	printf("3)main:dlclose libX.so\n");
	dlclose(libX);

        libAfn = dlsym(libA, "libA_func");
	if (!libAfn) {
		printf("dlsym error:libA_func:%s\n",dlerror());
		exit(-1);
	}
        libAfn();

	printf("6)main:dlclose libA.so\n");
        dlclose(libA);

	printf("8)main:finish main\n");
        return 0;
}
