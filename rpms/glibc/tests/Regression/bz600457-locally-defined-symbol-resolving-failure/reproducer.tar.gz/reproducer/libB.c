#include "libC.c"

void libB_func()
{
	libC_func();
}
