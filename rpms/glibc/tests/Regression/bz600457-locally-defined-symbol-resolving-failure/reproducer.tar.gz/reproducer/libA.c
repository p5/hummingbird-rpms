#include "libB.c"

void libA_func()
{
	libB_func();
}
